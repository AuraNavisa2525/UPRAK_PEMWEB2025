<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <title>Tambah Berita</title>
</head>

<body>
    <h2>Tambah Berita</h2>
    <form action="proses_tambah.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="Judul" required><br><br>
        <input type="file" name="thumbnail" accept="image/*" required><br><br>
        <textarea name="content" placeholder="Isi" required></textarea><br><br>
        <button type="submit">Simpan</button>
    </form>
    <p><a href="index.php">← Kembali</a></p>
</body>

</html>